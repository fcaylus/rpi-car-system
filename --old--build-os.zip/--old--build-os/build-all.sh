#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

function usage {
    cat <<EOF
Usage: $(basename $0) [params]
  All params are optional are there are default for each of them.

    -a, --arch=ARCH                  Arch of the result system (default: arm)
    -v, --vendor-tuple=VENDOR_TUPLE  Tuple used by the toolchain. It will prepend all compilers call
                                     (default: "arm-rpi-linux-gnueabihf")

    -d, --download-dir=DOWNLOAD_DIR  Directory used for donwload (default: $PWD/download)
    -b, --build-dir=BUILD_DIR        Directory used for compilation (default: $PWD/build)
    -s, --system-dir=SYSTEM_DIR      Directory used for the rpi system. It's the destination of all make install and will be archived at the end (default: $PWD/systemroot)

    -u, --toolchain-config-url=URL   Url where the crosstool-ng config is located (default: https://raw.githubusercontent.com/Toutjuste/crosstool-toolchains/master/confs/rpi-host-64-conf.config)
    
    -n, --tarball-name=TAR_NAME      The name of the result tarball (default: "rpi-car-system")

    -j, --job=JOB_NB                 Number of jobs for compilation (default: 1)
    -h, --help                       Show this message
EOF
}

##################
# Default values #
##################

BUILDOS_ARCH="arm"
BUILDOS_VENDOR_TUPLE="arm-rpi-linux-gnueabihf"
BUILDOS_DOWNLOAD_DIR="$PWD/download"
BUILDOS_BUILD_DIR="$PWD/build"
BUILDOS_SYSTEM_DIR="$PWD/systemroot"
BUILDOS_TOOL_URL="https://raw.githubusercontent.com/Toutjuste/crosstool-toolchains/master/confs/rpi-host-64-conf.config"
BUILDOS_TAR_NAME="rpi-car-system"
JOB_NB="1"


# Check no parameters
if [ $# -eq 0 ]
then
    echo -e "No parameters supplied. Use default values.\n"
fi

#List parameters
args=$(getopt -l "help,arch:,vendor-tuple:,download-dir:,build-dir:,system-dir:,toolchain-config-url:,tarball-name:,job:" -o "ha:v:d:b:s:u:n:j:" -- "$@")

eval set -- "$args"

#Check parameters
while [ $# -ge 1 ] ; do
    case "$1" in
        -h|--help) usage; exit 0;;
        -a|--arch)
            ARCH="$2";
            shift;;
        -v|--vendor-tuple)
            BUILDOS_VENDOR_TUPLE="$2";
            shift;;
        -d|--download-dir)
            BUILDOS_DOWNLOAD_DIR="$2";
            shift;;
        -b|--build-dir)
            BUILDOS_BUILD_DIR="$2";
            shift;;
        -s|--system-dir)
            BUILDOS_SYSTEM_DIR="$2";
            shift;;
        -u|--toolchain-url)
            BUILDOS_TOOL_URL="$2";
            shift;;
        -n|--tarball-name)
            BUILDOS_TAR_NAME="$2";
            shift;;
        -j|--job)
            JOB_NB="$2";
            shift;;
        --) shift; break;;
    esac
    shift
done

####################
# Start the script #
####################

# Save old path var
OLD_PATH=$PATH

TOOLS_DIR="${BUILDOS_BUILD_DIR}/${BUILDOS_VENDOR_TUPLE}"
TOOLS_PREFIX="${TOOLS_DIR}/bin/${BUILDOS_VENDOR_TUPLE}"
TOOLS_SYSROOT="${TOOLS_DIR}/${BUILDOS_VENDOR_TUPLE}/sysroot"

function set_cross_vars {

export CC=\""${TOOLS_PREFIX}-gcc\""
export CXX=\""${TOOLS_PREFIX}-g++\""
export AR=\""${TOOLS_PREFIX}-ar\""
export AS=\""${TOOLS_PREFIX}-as\""
export LD=\""${TOOLS_PREFIX}-ld\""
export RANLIB=\""${TOOLS_PREFIX}-ranlib\""
export READELF=\""${TOOLS_PREFIX}-readelf\""
export STRIP=\""${TOOLS_PREFIX}-strip\""

}

function set_std_vars {

export CC=gcc
export CXX=g++
export AR=ar
export AS=as
export LD=ld
export RANLIB=ranlib
export READELF=readelf
export STRIP=strip

}

# First arg must be the file name for saved state
# If first and second arg are an empty string, skip file check
# If first arg set, use file check (and set the second empty)
# If second arg is set, only check but don't write file on success
function test_cmd {
    local filename1="$1"
    local filename2="$2"

    # Check for file exist
    if [ -n "$filename1" ] || [ -n "$filename2" ]; then
        if [ -f "${BUILDOS_BUILD_DIR}/${filename1}.alreadydo" ] || [ -f "${BUILDOS_BUILD_DIR}/${filename2}.alreadydo" ]; then
            return;
        fi
    fi

    echo "Launch command ${@:3} ..."
    bash -c "${*:3}"

    local status=$?
    if [ $status -ne 0 ]; then
        echo "Error with ${@:3}" >&2
        export PATH=$OLD_PATH
        set_std_vars
        exit $status
    fi
    
    if [ -n "$filename1" ]; then
        # Write a file that tell the test has success !
        > "${BUILDOS_BUILD_DIR}/${filename1}.alreadydo"
    fi

    return $status
}

# Create directories
test_cmd "" "" mkdir -pv $BUILDOS_BUILD_DIR
test_cmd "" "" mkdir -pv $BUILDOS_DOWNLOAD_DIR
test_cmd "" "" mkdir -pv $BUILDOS_SYSTEM_DIR

#
# Download needed libraries
#

cd "$BUILDOS_DOWNLOAD_DIR"
wget -nc -O crosstool-conf.config https://raw.githubusercontent.com/Toutjuste/crosstool-toolchains/master/confs/rpi-host-64-conf.config
test_cmd "" "" wget -nc http://crosstool-ng.org/download/crosstool-ng/crosstool-ng-1.21.0.tar.bz2
test_cmd "" "" wget -nc http://busybox.net/downloads/busybox-1.23.2.tar.bz2
# BusyBox config
test_cmd "" "" wget -nc https://gist.githubusercontent.com/Toutjuste/e0b8983063f914c2f99b/raw/busybox-1.23.2.config
test_cmd "" "" wget -nc http://anduin.linuxfromscratch.org/sources/LFS/lfs-packages/conglomeration/iana-etc/iana-etc-2.30.tar.bz2
test_cmd "" "" wget -nc http://patches.clfs.org/embedded-dev/iana-etc-2.30-update-2.patch
test_cmd "" "" wget -nc https://github.com/raspberrypi/linux/archive/rpi-4.2.y.zip
wget -nc -O rpi-firmware.zip https://github.com/raspberrypi/firmware/archive/master.zip
test_cmd "" "" wget -nc http://dev.alpinelinux.org/bkeymaps/fr/fr-latin9.bmap
test_cmd "" "" wget -nc http://ftp.gnu.org/gnu/ncurses/ncurses-5.9.tar.gz
test_cmd "" "" wget -nc http://ftp.gnu.org/gnu/nano/nano-2.4.2.tar.gz
test_cmd "" "" wget -nc http://www.ijg.org/files/jpegsrc.v9a.tar.gz
test_cmd "" "" wget -nc http://zlib.net/zlib-1.2.8.tar.xz
test_cmd "" "" wget -nc http://prdownloads.sourceforge.net/libpng/libpng-1.6.18.tar.xz
test_cmd "" "" wget -nc http://download.savannah.gnu.org/releases/freetype/freetype-2.6.tar.bz2
test_cmd "" "" wget -nc ftp://xmlsoft.org/libxml2/libxml2-2.9.2.tar.gz
test_cmd "" "" wget -nc http://www.freedesktop.org/software/fontconfig/release/fontconfig-2.11.94.tar.bz2
wget -nc -O rpi-userland.zip https://github.com/raspberrypi/userland/archive/master.zip
test_cmd "" "" wget -nc https://gist.githubusercontent.com/Toutjuste/901e6edfa0cdddfdc07c/raw/arm-rpi-linux-gnueabihf.cmake
test_cmd "" "" wget -nc ftp://sourceware.org/pub/libffi/libffi-3.2.1.tar.gz
test_cmd "" "" wget -nc http://ftp.gnome.org/pub/gnome/sources/glib/2.45/glib-2.45.6.tar.xz
test_cmd "" "" wget -nc http://gstreamer.freedesktop.org/src/gstreamer/gstreamer-1.5.90.tar.xz
test_cmd "" "" wget -nc http://gstreamer.freedesktop.org/src/gst-plugins-base/gst-plugins-base-1.5.90.tar.xz
test_cmd "" "" wget -nc https://libav.org/releases/libav-11.4.tar.xz
test_cmd "" "" wget -nc http://gstreamer.freedesktop.org/src/gst-libav/gst-libav-1.5.90.tar.xz
test_cmd "" "" wget -nc http://sources.buildroot.net/DirectFB-1.6.3.tar.gz
test_cmd "" "" wget -nc http://ftp.gnome.org/pub/GNOME/sources/libsigc++/2.5/libsigc++-2.5.1.tar.xz
test_cmd "" "" wget -nc http://ilixi.org/releases/ilixi-1.0.0.tar.gz

cd "$BUILDOS_BUILD_DIR"
test_cmd "crosstool-tar" "" tar -xjvf "$BUILDOS_DOWNLOAD_DIR/crosstool-ng-1.21.0.tar.bz2"
test_cmd "busybox-tar" "" tar -xjvf "$BUILDOS_DOWNLOAD_DIR/busybox-1.23.2.tar.bz2"
test_cmd "iana-etc-tar" "" tar -xjvf "$BUILDOS_DOWNLOAD_DIR/iana-etc-2.30.tar.bz2"
test_cmd "linux-tar" "" unzip "$BUILDOS_DOWNLOAD_DIR/rpi-4.2.y.zip"
test_cmd "firmware-tar" "" unzip "$BUILDOS_DOWNLOAD_DIR/rpi-firmware.zip"
test_cmd "ncurses-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/ncurses-5.9.tar.gz"
test_cmd "nano-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/nano-2.4.2.tar.gz"
test_cmd "jpeg-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/jpegsrc.v9a.tar.gz"
test_cmd "zlib-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/zlib-1.2.8.tar.xz"
test_cmd "libpng-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/libpng-1.6.18.tar.xz"
test_cmd "freetype-tar" "" tar -xjvf "$BUILDOS_DOWNLOAD_DIR/freetype-2.6.tar.bz2"
test_cmd "libxml2-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/libxml2-2.9.2.tar.gz"
test_cmd "fontconfig-tar" "" tar -xjvf "$BUILDOS_DOWNLOAD_DIR/fontconfig-2.11.94.tar.bz2"
test_cmd "userland-tar" "" unzip "$BUILDOS_DOWNLOAD_DIR/rpi-userland.zip"
test_cmd "libffi-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/libffi-3.2.1.tar.gz"
test_cmd "glib-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/glib-2.45.6.tar.xz"
test_cmd "gstreamer-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/gstreamer-1.5.90.tar.xz"
test_cmd "gst-plugins-base-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/gst-plugins-base-1.5.90.tar.xz"
test_cmd "gst-libav-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/gst-libav-1.5.90.tar.xz"
test_cmd "libav-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/libav-11.4.tar.xz"
test_cmd "directfb-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/DirectFB-1.6.3.tar.gz"
test_cmd "libsigc++-tar" "" tar -xJvf "$BUILDOS_DOWNLOAD_DIR/libsigc++-2.5.1.tar.xz"
test_cmd "ilixi-tar" "" tar -xzvf "$BUILDOS_DOWNLOAD_DIR/ilixi-1.0.0.tar.gz"

#
# Create directories
#

mkdir -pv ${BUILDOS_SYSTEM_DIR}/{bin,boot,dev,etc,home,lib/{firmware,modules}}
mkdir -pv ${BUILDOS_SYSTEM_DIR}/{mnt,opt,proc,sbin,srv,sys}
mkdir -pv ${BUILDOS_SYSTEM_DIR}/var/{cache,lib,local,lock,log,opt,run,spool}
install -dv -m 0750 ${BUILDOS_SYSTEM_DIR}/root
install -dv -m 1777 ${BUILDOS_SYSTEM_DIR}/tmp
mkdir -pv ${BUILDOS_SYSTEM_DIR}/usr/{,local/}{bin,include,lib,sbin,share,src}

#
# Creating the log Files
#

ln -svf "${BUILDOS_SYSTEM_DIR}/proc/mounts" "${BUILDOS_SYSTEM_DIR}/etc/mtab"

touch "${BUILDOS_SYSTEM_DIR}/var/run/utmp" ${BUILDOS_SYSTEM_DIR}/var/log/{btmp,lastlog,wtmp}
chmod -v 664 "${BUILDOS_SYSTEM_DIR}/var/run/utmp" "${BUILDOS_SYSTEM_DIR}/var/log/lastlog"

#
# Build crosstool-ng
#

cd "$BUILDOS_BUILD_DIR/crosstool-ng-1.21.0"
# Create an another dir that contains the build tool
test_cmd "" "crosstool-compile" ./configure --prefix=\"${BUILDOS_BUILD_DIR}/crosstool-system\"
test_cmd "" "crosstool-compile" make -j${JOB_NB}
test_cmd "" "crosstool-compile" make install

test_cmd "crosstool-compile" "" echo \"crosstool-ng compiled !!!\"

#
# Build the toolchain
#

test_cmd "" "" mkdir -pv "$BUILDOS_BUILD_DIR/toolchain-build"
cd "$BUILDOS_BUILD_DIR/toolchain-build"

#test_cmd "" "toolchain-compile" cp \""$BUILDOS_DOWNLOAD_DIR/crosstool-conf.config"\" .config
# Change prefix (first, change / with \/ in the path for the sed command because sed use / internaly)
#ESCAPED_TOOLS_DIR=$(echo ${TOOLS_DIR} | sed 's/\//\\\//g')
#sed -ie "s/^CT_PREFIX_DIR.*/CT_PREFIX_DIR=\"${ESCAPED_TOOLS_DIR}\"/" .config
test_cmd "" "toolchain-compile" ${BUILDOS_BUILD_DIR}/crosstool-system/bin/ct-ng build.${JOB_NB}

test_cmd "toolchain-compile" "" echo \"Toolchain compiled !!!\"

#
# Set build VARS
#

export PATH="${TOOLS_DIR}/bin:$PATH"

set_cross_vars

#
# Build BusyBox
#

cd "$BUILDOS_BUILD_DIR/busybox-1.23.2"
test_cmd "" "busybox-compile" make distclean

cp "$BUILDOS_DOWNLOAD_DIR/busybox-1.23.2.config" .config

# Compile
test_cmd "" "busybox-compile" ARCH=\"${BUILDOS_ARCH}\" CROSS_COMPILE=\"${TOOLS_PREFIX}-\" make -j${JOB_NB}
# Install
test_cmd "" "busybox-compile" ARCH=\"${BUILDOS_ARCH}\" CROSS_COMPILE=\"${TOOLS_PREFIX}-\" make CONFIG_PREFIX=\"${BUILDOS_SYSTEM_DIR}\" install

test_cmd "busybox-compile" "" echo \"BusyBox compiled !!!\" 

#
# Build iana-etc
#

cd "$BUILDOS_BUILD_DIR/iana-etc-2.30"
test_cmd "" "iana-etc-compile" patch -Np1 -i $BUILDOS_DOWNLOAD_DIR/iana-etc-2.30-update-2.patch

test_cmd "" "iana-etc-compile" make get
test_cmd "" "iana-etc-compile" make STRIP=yes
test_cmd "" "iana-etc-compile" make DESTDIR=\"${BUILDOS_SYSTEM_DIR}\" install

test_cmd "iana-etc-compile" "" echo \"iana-etc compiled !!!\"

#
# Build ncurses
#

cd "$BUILDOS_BUILD_DIR/ncurses-5.9"

test_cmd "" "ncurses-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" ./configure --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\" --without-cxx-binding --without-ada --without-manpages --without-progs --without-normal --without-debug --without-tests --disable-big-core --with-shared --enable-widec
test_cmd "" "ncurses-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" -j${JOB_NB}
test_cmd "" "ncurses-compile" make install 

test_cmd "ncurses-compile" "" echo \"ncurses compiled !!!\"

#
# Build nano
#

cd "$BUILDOS_BUILD_DIR/nano-2.4.2"

ln -s ${BUILDOS_SYSTEM_DIR}/include/ncursesw/ncurses.h ${BUILDOS_SYSTEM_DIR}/include/

# Add ncurses libs to path
export PATH="${BUILDOS_SYSTEM_DIR}/lib:${BUILDOS_SYSTEM_DIR}/include:${BUILDOS_SYSTEM_DIR}/include/ncursesw:${PATH}:${BUILDOS_SYSTEM_DIR}/bin"

test_cmd "" "nano-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" CPPFLAGS=\"${CPPFLAGS} -I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/ncursesw\" CFLAGS=\"${CFLAGS} -I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/ncursesw\" LDFLAGS=\"${LDFLAGS} -L${BUILDOS_SYSTEM_DIR}/lib\" LIBS=\"-lncursesw\" NCURSESW_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lncursesw\" NCURSESW_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/ncursesw\" ./configure --enable-utf8 --enable-tiny --disable-glibtest --disable-nls --enable-color --enable-extra --enable-multibuffer --enable-nanorc --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "nano-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" -j${JOB_NB}
test_cmd "" "nano-compile" make install 

test_cmd "nano-compile" "" echo \"nano compiled !!!\"

#
# Build libjpeg
#

cd "$BUILDOS_BUILD_DIR/jpeg-9a"

test_cmd "" "jpeg-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" ./configure --enable-shared --disable-static --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\" --with-sysroot=\"${TOOLS_SYSROOT}\"
test_cmd "" "jpeg-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "jpeg-compile" make install

test_cmd "jpeg-compile" "" echo \"libjpeg compiled !!!\"

#
# Build zlib
#

cd "$BUILDOS_BUILD_DIR/zlib-1.2.8"

test_cmd "" "zlib-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc ./configure --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "zlib-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "zlib-compile" make install

test_cmd "zlib-compile" "" echo \"zlib compiled !!!\"

#
# Build libpng
#

cd "$BUILDOS_BUILD_DIR/libpng-1.6.18"

test_cmd "" "libpng-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lz\" CPPFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" ./configure --enable-shared --disable-static --enable-unversioned-links --disable-unversioned-libpng-pc --disable-unversioned-libpng-config --without-pkgconfigdir --without-binconfigs --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "libpng-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "libpng-compile" make install

test_cmd "libpng-compile" "" echo \"libpng compiled !!!\"

#
# Build freetype
#

cd "$BUILDOS_BUILD_DIR/freetype-2.6"
test_cmd "" "freetype-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" LIBPNG_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" LIBPNG_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lpng\" ZLIB_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" ZLIB_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lz\" ./configure --enable-shared --disable-static --disable-biarch-config --disable-mmap --with-zlib=yes --without-bzip2 --with-png=yes --without-harfbuzz --without-old-mac-fonts --without-fsspec --without-fsref --without-quickdraw-toolbox --without-quickdraw-carbon --without-ats --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "freetype-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "freetype-compile" make install

test_cmd "freetype-compile" "" echo \"freetype compiled !!!\"

#
# Build libxml2
#

cd "$BUILDOS_BUILD_DIR/libxml2-2.9.2"

test_cmd "" "libxml2-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" ./configure --enable-shared --disable-static --disable-rebuild-docs --disable-ipv6 --without-debug --without-ftp --without-history --without-html --without-http --without-icu --without-iconv --without-mem-debug --without-python --without-run-debug --without-lzma --without-coverage --without-zlib --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "libxml2-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "libxml2-compile" make install

test_cmd "libxml2-compile" "" echo \"libxml2 compiled !!!\"

#
# Build fontconfig
#

cd "$BUILDOS_BUILD_DIR/fontconfig-2.11.94"
test_cmd "" "fontconfig-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" FREETYPE_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/freetype2\" FREETYPE_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lfreetype\" LIBXML2_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/libxml2\" LIBXML2_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lxml2\" ./configure --enable-shared --disable-static --disable-iconv --enable-libxml2 --disable-docs --without-libiconv --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "fontconfig-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "fontconfig-compile" make install

test_cmd "fontconfig-compile" "" echo \"fontconfig compiled !!!\"

#
# Build rpi userland
#

cd "$BUILDOS_BUILD_DIR/userland-master"

test_cmd "" "userland-compile" mkdir -pv build/arm-linux/release/
test_cmd "" "userland-compile" cd build/arm-linux/release/
test_cmd "" "userland-compile" cmake -DCMAKE_TOOLCHAIN_FILE=\"${BUILDOS_DOWNLOAD_DIR}/arm-rpi-linux-gnueabihf.cmake\" -DCMAKE_BUILD_TYPE=Release \"$BUILDOS_BUILD_DIR/userland-master\"
test_cmd "" "userland-compile" make -j${JOB_NB}
test_cmd "" "userland-compile" make install DESTDIR=\"${BUILDOS_SYSTEM_DIR}\"

test_cmd "userland-compile" "" echo \"userland compiled !!!\"

#
# Build libffi
#

cd "$BUILDOS_BUILD_DIR/libffi-3.2.1"

test_cmd "" "libffi-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" ./configure --enable-shared --disable-static --disable-portable-binary --disable-debug --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "libffi-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" -j${JOB_NB}
test_cmd "" "libffi-compile" make install

# The headers are installed in the wrong dir, fix it !
test_cmd "" "libffi-compile" cp -f "${BUILDOS_SYSTEM_DIR}/lib/libffi-3.2.1/include/*.h" "${BUILDOS_SYSTEM_DIR}/include"
test_cmd "" "libffi-compile" rm -rf "${BUILDOS_SYSTEM_DIR}/lib/libffi-3.2.1"

test_cmd "libffi-compile" "" echo \"libffi compiled !!!\"

#
# Build glib
#

cd "$BUILDOS_BUILD_DIR/glib-2.45.6"

cat > rpi.cache <<EOF
glib_cv_long_long_format=ll
glib_cv_stack_grows=no 
glib_cv_sane_realloc=yes
glib_cv_have_strlcpy=no
glib_cv_va_val_copy=yes
glib_cv_rtldglobal_broken=no
glib_cv_uscore=no
glib_cv_monotonic_clock=no
ac_cv_func_nonposix_getpwuid_r=no 
ac_cv_func_posix_getpwuid_r=no
ac_cv_func_posix_getgrgid_r=no
glib_cv_use_pid_surrogate=yes 
ac_cv_func_printf_unix98=no
ac_cv_func_vsnprintf_c99=yes
ac_cv_func_realloc_0_nonnull=yes 
ac_cv_func_realloc_works=yes
EOF

test_cmd "" "glib-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" ZLIB_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" ZLIB_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lz\" LIBFFI_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" LIBFFI_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lffi\" ./configure --enable-shared --disable-static --disable-maintainer-mode --disable-debug --disable-gc-friendly --disable-installed-tests --disable-always-build-tests --enable-included-printf --disable-selinux --disable-fam --disable-xattr --disable-libelf --disable-gtk-doc --disable-gtk-doc-html --disable-gtk-doc-pdf --disable-man --disable-dtrace --disable-systemtap --disable-coverage --disable-compile-warnings --without-libiconv --with-pcre=internal --cache-file=rpi.cache --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "glib-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "glib-compile" make install

test_cmd "glib-compile" "" echo \"glib compiled !!!\"

#
# Build gstreamer
#

cd "$BUILDOS_BUILD_DIR/gstreamer-1.5.90"

test_cmd "" "gstreamer-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" GLIB_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/glib-2.0 -I${BUILDOS_SYSTEM_DIR}/lib/glib-2.0/include\" GLIB_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lglib-2.0\" GIO_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/gio-unix-2.0\" GIO_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lgio-2.0\" ./configure --enable-shared --disable-static --disable-nls --disable-rpath --disable-fatal-warnings --disable-gst-debug --disable-parse --disable-option-parsing --disable-trace --disable-alloc-trace --disable-registry --disable-debug --disable-profiling --disable-valgrind --disable-gcov --disable-examples --disable-static-plugins --disable-tests --disable-failing-tests --disable-benchmarks --disable-tools --disable-poisoning --disable-introspection --disable-docbook --disable-gtk-doc --disable-gtk-doc-html --disable-gtk-doc-pdf --disable-check --without-libiconv-prefix --without-libintl-prefix --with-ptp-helper-permissions=none --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "gstreamer-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "gstreamer-compile" make install

test_cmd "gstreamer-compile" "" echo \"gstreamer compiled !!!\"

#
# Build gst-plugins-base
#

cd "$BUILDOS_BUILD_DIR/gst-plugins-base-1.5.90"

test_cmd "" "gst-plugins-base-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" GLIB_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/glib-2.0 -I${BUILDOS_SYSTEM_DIR}/lib/glib-2.0/include\" GLIB_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lglib-2.0\" GIO_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/gio-unix-2.0\" GIO_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lgio-2.0\" GST_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include/gstreamer-1.0 -I${BUILDOS_SYSTEM_DIR}/lib/gstreamer-1.0/include\" GST_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lgstreamer-1.0\" GST_NET_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include/gstreamer-1.0\" GST_NET_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lgstnet-1.0\" GST_BASE_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include/gstreamer-1.0\" GST_BASE_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lgstbase-1.0\" GST_CONTROLLER_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include/gstreamer-1.0\" GST_CONTROLLER_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lgstcontroller-1.0\" ZLIB_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" ZLIB_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lz\" PKG_CONFIG_PATH=\"${BUILDOS_SYSTEM_DIR}/lib/pkgconfig\" LDFLAGS=\"-L${BUILDOS_SYSTEM_DIR}/lib\" LIBS=\"-lglib-2.0 -lgmodule-2.0 -lgobject-2.0 -lffi\" USE_GIO_UNIX_2_0=no  ./configure --enable-shared --disable-static --disable-nls --disable-rpath --disable-fatal-warnings --disable-debug --disable-profiling --disable-valgrind --disable-gcov --disable-examples --disable-introspection --disable-gtk-doc --disable-gtk-doc-html --disable-gtk-doc-pdf --disable-maintainer-mode --disable-orc --disable-static-plugins --disable-tcp --disable-x --disable-xvideo --disable-xshm --disable-cdparanoia --disable-pango --disable-theora --disable-alsa --disable-ivorbis --disable-libvisual --disable-ogg --disable-vorbis --disable-gio_unix_2_0 --disable-freetypetest --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "gst-plugins-base-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "gst-plugins-base-compile" make install

test_cmd "gst-plugins-base-compile" "" echo \"gst-plugins-base compiled !!!\"

#
# Build libav
#

#cd "$BUILDOS_BUILD_DIR/libav-11.4"

#test_cmd "" "libav-compile" CPPFLAGS_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lz\" ./configure --enable-shared --disable-static --enable-gray --disable-programs --disable-avconv --disable-avprobe --disable-avplay --disable-avserver --disable-doc --disable-w32threads --disable-network --disable-bzlib --disable-libcdio --enable-zlib --disable-runtime-cpudetect --enable-cross-compile --cc=${BUILDOS_VENDOR_TUPLE}-gcc --ar=${BUILDOS_VENDOR_TUPLE}-ar --ld=${BUILDOS_VENDOR_TUPLE}-ld --arch=armv6zk --cpu=arm1176jzf-s  --target-os=linux --prefix=\"${BUILDOS_SYSTEM_DIR}\" --cross-prefix=\"${BUILDOS_VENDOR_TUPLE}-\"
#test_cmd "" "libav-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
#test_cmd "" "libav-compile" make install

#test_cmd "libav-compile" "" echo \"libav compiled !!!\"

# --disable-armv6t2 --disable-armv5te --disable-amd3dnow --disable-amd3dnowext --disable-mmx --disable-mmxext --disable-sse --disable-sse2 --disable-sse3 --disable-ssse3 --disable-sse4 --disable-sse42 --disable-neon --disable-debug

#
# Build gst-libav
#

#cd "$BUILDOS_BUILD_DIR/gst-libav-1.5.90"

#exit

#
# Build DirectFB
#

cd "$BUILDOS_BUILD_DIR/DirectFB-1.6.3"

# TODO: add --without-tools ?
# TODO: compile less drivers, a lot are useless for the car system
test_cmd "" "directfb-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" FREETYPE_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/freetype2\" FREETYPE_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lfreetype\" LIBPNG_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include\" LIBPNG_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lpng\" EGL_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/opt/vc/include -I${BUILDOS_SYSTEM_DIR}/opt/vc/include/interface/vcos/pthreads\" EGL_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/opt/vc/lib -lEGL -lGLESv2\" CPPFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/gstreamer-1.0 -I${BUILDOS_SYSTEM_DIR}/include/gstreamer-1.0/gst -I${BUILDOS_SYSTEM_DIR}/include/glib-2.0 -I${BUILDOS_SYSTEM_DIR}/include/libxml2\" LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -lz -ljpeg -lglib-2.0 -lgmodule-2.0 -lgobject-2.0 -lgstapp-1.0 -lgstbase-1.0 -lgstreamer-1.0 -lxml2 -lffi\" PKG_CONFIG_PATH=\"${BUILDOS_SYSTEM_DIR}/lib/pkgconfig\" ./configure --enable-shared --disable-static --disable-osx --disable-x11 --disable-x11vdpau --disable-extra-warnings --disable-profiling --disable-debug --enable-debug-support --enable-trace --disable-network --disable-multi --disable-multicore --disable-voodoo --disable-mmx --disable-sse --disable-pvr2d --enable-egl --enable-fbdev --disable-sdl --disable-vnc --disable-mesa --enable-jpeg --disable-mng --disable-svg --enable-zlib --enable-png --disable-imlib2 --disable-mpeg2 --disable-bmp --disable-jpeg2000 --disable-gif --enable-freetype --disable-linotype --disable-video4linux --disable-video4linux2 --with-gfxdrivers=gles2 --with-smooth-scaling --without-tests --enable-gstreamer --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "directfb-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" CFLAGS=\"-Wall -Wstrict-prototypes -Wmissing-prototypes -Wno-strict-aliasing -O2 -g2 -ffast-math -pipe -D_GNU_SOURCE -finstrument-functions -std=gnu99\" -j${JOB_NB}
test_cmd "" "directfb-compile" make install

test_cmd "directfb-compile" "" echo \"directfb compiled !!!\"
# -I/usr/include/gstreamer-0.10 -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include -I/usr/include/libxml2  -lgstapp-0.10 -lgstbase-0.10 -lgstreamer-0.10 -lgobject-2.0 -lgmodule-2.0 -pthread -lgthread-2.0 -pthread -lglib-2.0 -lxml2

#
# Build libsigc++
#

cd "$BUILDOS_BUILD_DIR/libsigc++-2.5.1"

test_cmd "" "libsigc++-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" ./configure --enable-shared --disable-static --disable-documentation --enable-warnings=no --without-libstdc-doc --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "libsigc++-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" -j${JOB_NB}
test_cmd "" "libsigc++-compile" make install

test_cmd "libsigc++-compile" "" echo \"libsigc++ compiled !!!\"

#
# Build ilixi
#

cd "$BUILDOS_BUILD_DIR/ilixi-1.0.0"

# TODO: disable examples
test_cmd "" "ilixi-compile" CC=${BUILDOS_VENDOR_TUPLE}-gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" DEPS_CFLAGS=\"-I${BUILDOS_SYSTEM_DIR}/include -I${BUILDOS_SYSTEM_DIR}/include/directfb -I${BUILDOS_SYSTEM_DIR}/include/directfb-internal -I${BUILDOS_SYSTEM_DIR}/include/sigc++-2.0 -I${BUILDOS_SYSTEM_DIR}/lib/sigc++-2.0/include -I${BUILDOS_SYSTEM_DIR}/include/libxml2\" DEPS_LIBS=\"-L${BUILDOS_SYSTEM_DIR}/lib -ldirectfb -ldirect -lsigc-2.0 -lxml2 -lfontconfig\" CFLAGS=\"-std=c++11\" DFB_SURFACE_EVENTS=yes ./configure --enable-shared --enable-log --disable-log-debug --disable-debug --enable-trace --disable-profiling --disable-stereoscopy --disable-fusiondale --disable-fusionsound --disable-sawman --disable-reflex --disable-wnn --disable-nls --disable-rpath --disable-doxygen-doc --disable-doxygen-dot --disable-doxygen-man --disable-doxygen-rtf --disable-doxygen-xml --disable-doxygen-chm --disable-doxygen-chi --disable-doxygen-html --disable-doxygen-ps --disable-doxygen-pdf --without-libiconv-prefix --without-libintl-prefix --with-examples --host=\"${BUILDOS_VENDOR_TUPLE}\" --prefix=\"${BUILDOS_SYSTEM_DIR}\"
test_cmd "" "ilixi-compile" make HOSTCC=gcc CXX=${BUILDOS_VENDOR_TUPLE}-g++ AR=\""${TOOLS_PREFIX}-ar\"" LD=\""${TOOLS_PREFIX}-ld\"" CFLAGS=\"-DILIXI_DATADIR=/share/ilixi-1.0.0\" -j${JOB_NB}
test_cmd "" "ilixi-compile" make install

test_cmd "ilixi-compile" "" echo \"ilixi compiled !!!\"

#
# Build linux kernel
#

cd "$BUILDOS_BUILD_DIR/linux-rpi-4.2.y"

# Reset path variable
export PATH=$OLD_PATH

test_cmd "" "linux-compile" make mrproper
test_cmd "" "linux-compile" make ARCH=\"${BUILDOS_ARCH}\" CROSS_COMPILE=\"${TOOLS_PREFIX}-\" bcmrpi_defconfig
test_cmd "" "linux-compile" make ARCH=\"${BUILDOS_ARCH}\" CROSS_COMPILE=\"${TOOLS_PREFIX}-\" -j${JOB_NB}
test_cmd "" "linux-compile" make ARCH=\"${BUILDOS_ARCH}\" CROSS_COMPILE=\"${TOOLS_PREFIX}-\" INSTALL_MOD_PATH=\"${BUILDOS_SYSTEM_DIR}\" modules_install

test_cmd "linux-compile" "" echo \"Linux kernel compiled !!!\"

test_cmd "linux-copy" "" cp arch/arm/boot/zImage ${BUILDOS_SYSTEM_DIR}/boot/kernel.img

#
# Set the official bootloader
#

cd "$BUILDOS_BUILD_DIR/firmware-master/boot"

# Copy all files to /boot dir
test_cmd "firmware-copy" "" cp -r LICENCE.broadcom bcm2708-rpi-b.dtb bootcode.bin start.elf overlays/ ${BUILDOS_SYSTEM_DIR}/boot/

#
# Copy all scripts
#

cd "${SCRIPT_DIR}/scripts"

# 755 for dir
# 754 for executable or scripts
# 644 for config files

#
# Start and stop files
test_cmd "" "scripts-copy" install -d -m 755 ${BUILDOS_SYSTEM_DIR}/etc/rc.d/init.d
test_cmd "" "scripts-copy" install -d -m 755 ${BUILDOS_SYSTEM_DIR}/etc/rc.d/start
test_cmd "" "scripts-copy" install -d -m 755 ${BUILDOS_SYSTEM_DIR}/etc/rc.d/stop
test_cmd "" "scripts-copy" install -m 644 etc/rc.d/init.d/functions ${BUILDOS_SYSTEM_DIR}/etc/rc.d/init.d/
test_cmd "" "scripts-copy" install -m 754 etc/rc.d/startup          ${BUILDOS_SYSTEM_DIR}/etc/rc.d/
test_cmd "" "scripts-copy" install -m 754 etc/rc.d/shutdown         ${BUILDOS_SYSTEM_DIR}/etc/rc.d/
test_cmd "" "scripts-copy" install -m 754 etc/rc.d/init.d/syslog    ${BUILDOS_SYSTEM_DIR}/etc/rc.d/init.d/
test_cmd "" "scripts-copy" ln -sf ../init.d/syslog ${BUILDOS_SYSTEM_DIR}/etc/rc.d/start/S05syslog
test_cmd "" "scripts-copy" ln -sf ../init.d/syslog ${BUILDOS_SYSTEM_DIR}/etc/rc.d/stop/K99syslog

test_cmd "" "scripts-copy" install -m 754 etc/inittab ${BUILDOS_SYSTEM_DIR}/etc/
test_cmd "" "scripts-copy" install -m 644 etc/fstab ${BUILDOS_SYSTEM_DIR}/etc/

#
# Boot files
test_cmd "" "scripts-copy" install -m 644 boot/config.txt ${BUILDOS_SYSTEM_DIR}/boot/
test_cmd "" "scripts-copy" install -m 644 boot/cmdline.txt ${BUILDOS_SYSTEM_DIR}/boot/

#
# mdev file
test_cmd "" "scripts-copy" install -m 644 etc/mdev.conf ${BUILDOS_SYSTEM_DIR}/etc/

#
# profile file
test_cmd "" "scripts-copy" install -m 754 etc/profile ${BUILDOS_SYSTEM_DIR}/etc/
test_cmd "" "scripts-copy" install -m 644 etc/nanorc ${BUILDOS_SYSTEM_DIR}/etc/

#
# groups and users
test_cmd "" "scripts-copy" install -m 644 etc/group ${BUILDOS_SYSTEM_DIR}/etc
test_cmd "" "scripts-copy" install -m 644 etc/passwd ${BUILDOS_SYSTEM_DIR}/etc
test_cmd "" "scripts-copy" install -m 644 etc/hosts ${BUILDOS_SYSTEM_DIR}/etc

#
# GUI
test_cmd "" "scripts-copy" install -m 644 etc/directfbrc ${BUILDOS_SYSTEM_DIR}/root
test_cmd "" "scripts-copy" mv ${BUILDOS_SYSTEM_DIR}/root/directfbrc ${BUILDOS_SYSTEM_DIR}/root/.directfbrc

#
# i18n
test_cmd "" "scripts-copy" install -d -m 755 ${BUILDOS_SYSTEM_DIR}/etc/i18n
test_cmd "" "scripts-copy" install -m 644 "$BUILDOS_DOWNLOAD_DIR/fr-latin9.bmap" ${BUILDOS_SYSTEM_DIR}/etc/i18n

test_cmd "scripts-copy" "" echo \"All scripts installed !\"

#
# Copy GCC librairies
#

cd "${BUILDOS_SYSTEM_DIR}/"

test_cmd "" "lib-copy" cp -f ${TOOLS_SYSROOT}/lib/*.so* lib/
test_cmd "" "lib-copy" cp -f ${TOOLS_SYSROOT}/lib/*.a lib/
mkdir -p lib/ldscripts
test_cmd "" "lib-copy" cp -f ${TOOLS_SYSROOT}/lib/ldscripts/* lib/ldscripts

test_cmd "" "lib-copy" cp -f ${TOOLS_SYSROOT}/usr/lib/*.so* usr/lib
test_cmd "" "lib-copy" cp -f ${TOOLS_SYSROOT}/usr/lib/*.a usr/lib
test_cmd "" "lib-copy" rm -f usr/lib/*.o
test_cmd "" "lib-copy" cp -rf opt/vc/lib/* lib/

test_cmd "lib-copy" "" echo \"All GCC libs installed !\"

#
# Try to remove useless files
# Don't exit on error since the files may not appear
#

rm -v ${BUILDOS_SYSTEM_DIR}/bin/freetype-config
rm -v ${BUILDOS_SYSTEM_DIR}/lib/*.la
rm -v ${BUILDOS_SYSTEM_DIR}/lib/weston/*.la
rm -vr ${BUILDOS_SYSTEM_DIR}/lib/pkgconfig
rm -v ${BUILDOS_SYSTEM_DIR}/lib/*.pc
rm -vf ${BUILDOS_SYSTEM_DIR}/lib/*.py
rm -vr ${BUILDOS_SYSTEM_DIR}/share/aclocal
rm -vr ${BUILDOS_SYSTEM_DIR}/share/doc
rm -vr ${BUILDOS_SYSTEM_DIR}/share/gtk-doc
rm -vr ${BUILDOS_SYSTEM_DIR}/share/man
rm -vr ${BUILDOS_SYSTEM_DIR}/share/pkgconfig
rm -v ${BUILDOS_SYSTEM_DIR}/bin/ncursesw5-config

#
# Setting Hostname
#

TARGET_HOSTNAME="rpi-car-system"
echo "${TARGET_HOSTNAME}" > ${BUILDOS_SYSTEM_DIR}/etc/HOSTNAME

#
# Create the final tarball
#

cd ${BUILDOS_SYSTEM_DIR}

# When uncompressing the tarball, make sure to pass tar the "-p" switch to ensure permissions are preserved.
tar -jcvf ../${BUILDOS_TAR_NAME}.tar.bz2 *

echo "----------------------------------"
echo "Build Finish !!!!"
echo "----------------------------------"

export PATH=$OLD_PATH
set_std_vars



